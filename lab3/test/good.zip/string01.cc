void main () {
	string s1 ; 
	s1 = readString() ;
	printString(s1) ;
	string s2 = readString() ;
	printString(s2) ;
	printString(s1 + " " + s2) ;
}