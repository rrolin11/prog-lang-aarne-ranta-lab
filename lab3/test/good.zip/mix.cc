void main () {
	int a, b ;
	a = 1 ;
	b = 2 ;
	double c, d ;
	c = 4.5 ;
	d = 0.5 ;
	printString("a = " + i2Str(a)) ;
	printString("b = " + i2Str(b)) ;
	printString("a + b = " + i2Str(a + b)) ;
	
	printString("c = " + d2Str(c)) ;
	printString("d = " + d2Str(d)) ;
	printString("c + d = " + d2Str(c + d)) ;

}