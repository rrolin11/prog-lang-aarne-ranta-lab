void main() {
	2 + 3 ;
}