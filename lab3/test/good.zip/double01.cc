void main () {
	double d ;
	d = readDouble() ;
	printDouble(d) ;
	while (d < 26.0) {
		d++ ;
		printDouble(d) ;
	}
}